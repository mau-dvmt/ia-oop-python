import peewee as pw

db = pw.SqliteDatabase("MauTwitter.db")

class BaseModel(pw.Model):
     ''' This is the base class from which all our other classes will inherit 
         The benefit of having a common class is that we don't have to set the configuration in every other class.
     '''

     class Meta:
         ''' In Meta nested class we provide the configuration '''
         database = db
