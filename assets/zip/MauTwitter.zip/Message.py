from BaseModel import *
from User import User

class Message(BaseModel):
    '''Modellen för våra meddelande'''

    user = pw.ForeignKeyField(User, backref='messages')
    message = pw.TextField()
    timestamp = pw.TimestampField()
    likes = pw.IntegerField()



