from User import User
from Message import Message

class MauTwitter():

    def __init__(self, *args, **kwargs):
        self.create_tables()

    def create_tables(self):
        '''Skapar de databas-tabeller som vi behöver för att köra programmet'''
        User.create_table()
        Message.create_table()

    def create_user(self, **kwargs):
        '''Skapar en användare i databasen'''
        return User.create(**kwargs)
        
    def get_user(self, username):
        '''Hämtar en användare från databasen'''
        try:
            return User.get(User.username == username)

        except:
            return None

    def get_users(self):
        '''Hämtar alla användare från databasen'''
        return User.select()

    def create_message(self, **kwargs):
        '''Skapar ett meddelande'''
        return Message.create(**kwargs)

    def get_messages(self):
        '''Hämtar alla meddelande från databasen'''
        return Message.select()

    def get_messages_by_username(self, username):
        '''Hämtar alla meddelande från en given användare i databasen'''
        return Message.select().join(User).where(User.username == username)
