from MauTwitter import MauTwitter
from datetime import datetime

class App:
    '''Huvudklassen för vårt program som anvsvarar för MauTwitter och interaktion med användaren'''

    def __init__(self):
        '''Skapar var MauTwitter, sätter den aktuella användaren, kör sedan menyn'''
        self.mau_twitter = MauTwitter()
        self.user = self.get_user()
        self.menu()

    def get_user(self):
        '''Om användaren inte finns, skapa användaren. Annars hämta användaren från databasen'''
        username = input("Ange användarnamn: ")
        user = self.mau_twitter.get_user(username)
        
        if user == None:
            print("Din användare finns inte, låt oss skapa användaren!")
            name = input("Ange ditt hela namn: ")
            password = input("Ange ditt lösenord: ")
            email = input("Ange din epost-adress: ")
            
            user = self.mau_twitter.create_user(username=username, full_name=name,
                                                password=password, email=email)
            print("> Användare skapad, välkommen {}!".format(user.username))
        else:
            print("Välkommen tillbaka {}!".format(user.username))

        return user


    def menu(self):
        '''Hanterar menyn och användarens val'''
        while True:
            self.print_menu()
            user_choice = input("Val: ")

            if user_choice == "1":
                self.show_messages()
            elif user_choice == "2":
                self.show_user_messages()
            elif user_choice == "3":
                self.show_users()
            elif user_choice == "4":
                self.create_new_message()
            elif user_choice == "0":
                break
            else:
                print("Du valde ett felaktigt alternativ - försök igen!")

    def print_menu(self):
        '''Skriver ut menyn'''
        print("\n\n")
        print("*"*10)
        print("1) Visa alla meddelande")
        print("2) Visa meddelande från en specifik användare")
        print("3) Visa alla användare")
        print("4) Skapa en meddelande")
        print("0) Avsluta")
        print("*"*10)

    def show_messages(self):
        '''Skriver ut alla meddelande som finns sparade i vår databas'''
        messages = self.mau_twitter.get_messages()

        if len(messages) == 0:
            print("> Det finns inga meddelande")
        else:
            print("-"*10)
            print("Meddelande")
            print("-"*10)
            for message in messages:
                print("{} ({}): {}".format(message.user.username, message.timestamp, message.message))

    def show_user_messages(self):
        '''Skriver ut alla meddelande som finns kopplade till en specifik användare, sparade i vår databas'''
        username = input("Användarnamn: ")
        messages = self.mau_twitter.get_messages_by_username(username)

        if len(messages) == 0:
            print("> Det finns inga meddelande")
        else:
            print("-"*10)
            print("Meddelande")
            print("-"*10)
            for message in messages:
                print("{} ({}): {}".format(message.user.username, message.timestamp, message.message))


    def show_users(self):
        '''Skriver ut alla användare som finns sparade i vår databas'''
        users = self.mau_twitter.get_users()

        if len(users) == 0:
            print("> Det finns inga användare")
        else:
            print("-"*10)
            print("Användare")
            print("-"*10)
            for user in users:
                print("{} ({})".format(user.username, user.full_name))

    def create_new_message(self):
        '''Skapar ett meddelande och sparar det i vår databas'''
        print("-"*10)
        print("Skapa ett meddelande!")
        print("-"*10)
        message = input("> ")
        timestamp = datetime.now()
        self.mau_twitter.create_message(user=self.user, message=message, timestamp=timestamp, likes=0)
        print("Tack för ditt meddelande!")


App()