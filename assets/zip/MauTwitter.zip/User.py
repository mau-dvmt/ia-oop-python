from BaseModel import *

class User(BaseModel):
    '''Modellen för våra användare'''

    username = pw.CharField(unique=True)
    full_name = pw.CharField()
    password = pw.CharField()
    email = pw.CharField()




    