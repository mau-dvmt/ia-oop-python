class Dog:
    """
    Klassen beskriver en hund
    """

    def __init__(self, name, breed, age, color):
        """
        Sätter klassens attribut
        """
        self.name = name
        self.breed = breed
        self.age = age
        self.asleep = True
        self.color = color

    def get_name(self):
        return self.name

    def is_asleep(self):
        """
        Kontrollerar om hunden sover
        """
        if self.asleep:
            return True
        else:
            return False

    def wake_up(self):
        """
        Väcker hunden
        """
        self.asleep = False

    def sleep(self):
        """
        Hunden somnar
        """
        self.asleep = True

    def print_fur_colors(self):
        """
        Skriver ut hunden färger
        """
        print("{} has the following fur colors: {}.".format(self.name, ", ".join(self.color)))

    def __str__(self):
        """
        Ger en utskriftvänlig version av hunden
        """
        return "Woof! My name is {}!".format(self.name)



# --- Exempelkod från övningen ---
# Vår instans av klassen Dog
dog = Dog("Doug", "Pug", 8, ["black", "white", "beige"])

print(dog)
# => "Woof! I'm Doug the pug (8 years)."

# Testa gärna att köra dog.sleep() innan if-satsen
# för att se så att båda delarna ger utskrifter
if dog.is_asleep():
    dog.wake_up()
    print(dog.get_name(), "just woke up!")
    # => "Doug just woke up!"
else:
    dog.sleep()
    print(dog.get_name(), "is fast asleep!")
    # => "Doug is fast asleep!"

dog.print_fur_colors()
# => "Doug has the following fur colors: black, white, beige."

