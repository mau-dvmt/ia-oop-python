class Dog:
    """
    Klassen beskriver en hund
    """

    def __init__(self, name):
        """
        Sätter klassens attribut
        """
        self.name = name

    def __str__(self):
        """
        Ger en utskriftvänlig version av hunden
        """
        return "Woof! My name is {}!".format(self.name)

d = Dog("Doug")
print(d)
