class Dog:
    """
    Klassen beskriver en hund
    """

    def __init__(self, name, breed, age, color):
        """
        Sätter klassens attribut
        """
        self.name = name
        self.breed = breed
        self.age = age
        self.asleep = True
        self.color = color

    def get_name(self):
        return self.name

    def is_asleep(self):
        """
        Kontrollerar om hunden sover
        """
        if self.asleep:
            return True
        else:
            return False

    def wake_up(self):
        """
        Väcker hunden
        """
        self.asleep = False

    def sleep(self):
        """
        Hunden somnar
        """
        self.asleep = True

    def print_fur_colors(self):
        """
        Skriver ut hunden färger
        """
        print("{} has the following fur colors: {}.".format(self.name, ", ".join(self.color)))

    def __str__(self):
        """
        Ger en utskriftvänlig version av hunden
        """
        return "Woof! My name is {}!".format(self.name)



# Skapar 5st hundar
dogs = []
dogs.append(Dog("Doug", "pug", 3, ["white", "brown", "black"]))
dogs.append(Dog("Bella", "labrador retriever", 3, ["white", "black"]))
dogs.append(Dog("Milo", "bulldog", 3, ["white", "brown"]))
dogs.append(Dog("Coco", "beagle", 3, ["white", "grey"]))
dogs.append(Dog("Daisy", "poodle", 3, ["grey", "black"]))

for dog in dogs:
    print(dog, end="")
    dog.print_fur_colors()
