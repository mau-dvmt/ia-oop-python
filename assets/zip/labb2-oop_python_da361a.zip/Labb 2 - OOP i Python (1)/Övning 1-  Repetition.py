dog = {
    "name": "Doug",
    "breed": "Pug",
    "age": 3,
    "asleep": False,
    "color": ["White", "Brown", "Black"]
}

def print_info(dog):
    print("Woof! I'm {} the {} ({} years).".format(dog["name"], dog["breed"].lower(), dog["age"]))

def is_asleep(dog):
    if dog["asleep"]:
        return True
    else:
        return False

def wake_up(dog):
    dog["asleep"] = False

def sleep(dog):
    dog["asleep"] = True

def print_fur_colors(dog):
    print("{} has the following fur colors: {}.".format(dog["name"], ", ".join(dog["color"]).lower()))

# --- Del 1 ---
print_info(dog)


# --- Del 2 ---
# If-sats som kontrollerar om hunden sover eller inte
if is_asleep(dog):
    print(dog["name"], "is sleeping!")
    # => "Doug is sleeping!"
else:
    print(dog["name"], "is awake!")
    # => "Doug is awake!"


# --- Del 3 ---
# Beroende på om hunden sover eller inte så ändrar vi tillståendet på "asleep" nyckeln
if is_asleep(dog):
    wake_up(dog)
    print(dog["name"], "just woke up!")
    # => "Doug just woke up!"
else:
    sleep(dog)
    print(dog["name"], "is fast asleep!")
    # => "Doug is fast asleep!"


# --- Del 4 ---
print_fur_colors(dog)
