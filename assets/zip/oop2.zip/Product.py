class Product(object):

    def __init__(self, productnumber, price, name):
        self.productnumber = productnumber
        self.price = price
        self.name = name

    def get_productnumber(self):
        return self.productnumber

    def set_productnumber(self, pn):
        self.productnumber = pn

    def get_price(self):
        return self.price

    def set_price(self, price):
        self.price = price

    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name
