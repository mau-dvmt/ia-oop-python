from Usb import *
from Inventory import *

class Shop(object):

    def __init__(self, name):
        self.name = name
        # Create a new instance of a inventory (empty)
        self.inventory = Inventory()

    def start(self):
        # Welcome message
        print("Welcome to %s" % (self.name))
        # User menu choice
        choice = ""
        
        while choice != "3":
            # Menu
            print("1) List products, 2) Add product, 3) Exit")
            # User menu choice
            choice = input("Choice: ")
            # Check user choice
            if choice == "1":
                # List all products
                self.print_products()
            elif choice == "2":
                # Create a new product
                self.create_product()

        # Goodbye message
        print("Bye!")

    def print_products(self):
        # Fetch all saved products from inventory
        products = self.inventory.get_products()
        # Loop through all products and print each product
        for product in products:
            # This will invoke __str__ @ the Usb class
            print(product)
        
    def create_product(self):
        # Get user input for our product
        name = input("Name: ")
        pn = input("Productnumber: ")
        price = input("Price: ")
        size = input("Size(GB): ")
        # Create our product
        product = Usb(pn, name, price, size)
        # Add our product to the inventory
        self.inventory.add_product(product)

        print("Product has been added!")

# Start the program
shop = Shop("Teknikbutiken")
shop.start()
