class MedicalNote:

    def __init__(self, date, author, text, id):
        self._id = id
        self._date = date
        self._author = author
        self._text = text

    def get_author(self):
        return self._author

    def get_date(self):
        return self._date

    def get_text(self):
        return self._text

    def get_id(self):
        return self._id