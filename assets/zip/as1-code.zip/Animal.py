from MedicalRecord import MedicalRecord

class Animal:
    """
    A class used to represent an Animal

    Attributes
    ----------
    id : int
        A unique identifier for the animal
    name : str
        The name of the animal
    medical_record : MedicalRecord
        The animals medical record
    owner: Owner
        The owner of the animal

    Methods
    -------
    get_journals()
        Returns the medical records of the animal

    get_owners()
        Returns the owners of the animal

    get_name()
        Returns the name of the animal
    """

    def __init__(self, id, name):
        """Creates a new animal

        Args:
            id (int) : A unique identifier of the animal
            name (str) : The name of the animal 
        """
        self.id = id
        self._name = name
        self._medical_record = MedicalRecord()
        self._owner = []

    def get_journals(self, pnr):
        """Returns the medical records of an animal, given the personal
           number of an employee

        Args:
            pnr (str) : A peronal number

        Returns:
            []MedicalNote : A list of medical notes written by the given employee
        """
        pass

    def get_owners(self):
        """Returns the owners for the animal

        Returns:
            []Owners : A list of the animals owners
        """
        pass

    def get_name(self):
        """Returns the name of the animal

        Returns:
            str : The name of the animal
        """
        return self.name