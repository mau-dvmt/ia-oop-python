from Person import Person

class Owner(Person):

    def __init__(self, name, pnr):
        self._animals = []
        super().__init__(name, pnr)

    def get_animals(self):
        return self._animals