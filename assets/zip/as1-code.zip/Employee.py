from Person import Person

class Employee(Person):
    """
    A class used to represent an Employee

    Attributes
    ----------
    position : str
        The employees position in the organisation

    Methods
    -------
    get_position()
        Returns the employees position in the organisation
    """

    def __init__(self, name, pnr, position):
        """Creates a new Employee

        Args:
            name (str) : Name of the employee
            pnr (str) : Personal number of the employee
            position (str) : Position of the employee
        """
        self._position = position
        super().__init__(name, pnr)

    def get_position(self):
        """Get the position of the employee

        Returns:
            str : The position of the employee
        """
        return self._position