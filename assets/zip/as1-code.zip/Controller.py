class Controller:
    """
    A class used to represent a Controller

    Attributes
    ----------
    staff : Employee[]
        A list of employees in program
    owners : Owner[]
        A list of owners in program
    animals : Animal[]
        A list of animals in program

    Methods
    -------
    print_journal(animal: Animal, author: Employee)
        Prints the journal for an anminal, by an employee 

    send_to_printer(text: str)
        Send the text to a printer
    """

    def __init__(self):
        """Creates a new controller"""
        self._staff = []
        self._owners = []
        self._animals = []

    def print_journal(self, animal, author):
        """Creates a new controller

        Args:
            animal (Animal): The animal that the journal belongs to
            author (Employee): The employee that has written the medical notes
        """
        pass

    def send_to_printer(self, text):
        """Send a given text to the printer

        Args:
            text (str): The text that will be printed
        """
        pass


