class Person:

    def __init__(self, name, pnr):
        self._name = name
        self._pnr = pnr

    def get_name(self):
        return self._name

    def get_pnr(self):
        return self.pnr