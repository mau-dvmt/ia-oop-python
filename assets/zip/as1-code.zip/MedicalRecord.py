from MedicalRecord import MedicalRecord

class MedicalRecord:

    def __init__(self):
        self.medical_notes = []
    
    def get_medical_notes(self):
        pass