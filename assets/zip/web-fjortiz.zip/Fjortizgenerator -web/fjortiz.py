import json
import random

fjotiz_dict = False

def translate(input_text):
	global fjotiz_dict
	fjotiz_dict = read_dictionary("fjortiz.json")

	input_text = input_text.lower()

	# Ändra ord
	for word in fjotiz_dict["words"]:
		input_text = input_text.replace(word, fjotiz_dict["words"][word])

        #Särskrivning
	for word in fjotiz_dict["separate"]:
		input_text = input_text.replace(word, word+" ")

	# Vid meningens slut
	input_text = input_text.replace(".", change_dot())

	return input_text

def read_dictionary(file_name):
	try:
		with open(file_name) as data_file:
			data = json.load(data_file)
			return data
	except:
		print("Kunde inte öppna filen")

def translate_user_input():
	input_text = input("Vad vill du översätta? ").lower()

	# Ändra ord
	for word in fjotiz_dict["words"]:
		input_text = input_text.replace(word, fjotiz_dict["words"][word])

    #Särskrivning
	for word in fjotiz_dict["separate"]:
		input_text = input_text.replace(word, word+" ")

	# Vid meningens slut
	input_text = input_text.replace(".", change_dot())

	print("*"*40)
	print(input_text)
	print("*"*40)

def change_dot():
	dot_endings = fjotiz_dict["random"]
	return " {}.".format(random.choice(dot_endings))
	
def add_word():
	word = input("Ange ord du vill översätta: ")
	new_word = input("Ange översättningen: ")
	global fjotiz_dict
	fjotiz_dict["words"][word] = new_word
	save_dict()
	
def save_dict():
	try:
		file = open("fjortiz.json", "w")
		file.write(json.dumps(fjotiz_dict, indent=4))
	except:
		print("Kunde inte spara till filen")
