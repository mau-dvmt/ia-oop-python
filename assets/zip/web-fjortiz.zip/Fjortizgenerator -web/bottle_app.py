from bottle import route, run, template, request
import fjortiz

@route('/')
def index():
    return template("index", text="")

@route('/translate', method='POST')
def translate():
    user_message = request.forms.message
    translated_message = fjortiz.translate(user_message)
    return template("index", text=translated_message)

run(host='localhost', port=8080, debug=True)
